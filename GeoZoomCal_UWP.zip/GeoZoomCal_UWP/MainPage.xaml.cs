﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.ComponentModel;
using System.Globalization;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace GeoZoomCal_UWP
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
    }

    public class CustomGrid: Grid
    {
        public Position Northeast { get; set; }
    }

    /// <summary>
    /// Defines the position struct
    /// </summary>
    [TypeConverter(typeof(PositionConverter))]
    public struct Position
    {
        /// <summary>
        /// Gets or sets the latitude of map position in decimal degrees
        /// </summary>
        public double Latitude { get; }

        /// <summary>
        /// Gets or sets the longitude of map position in decimal degrees
        /// </summary>
        public double Longitude { get; }

        /// <summary>
        /// Defines the position struct constructor
        /// </summary>
        /// <param name="latitude">latitude value</param>
        /// <param name="longitude">longitude value</param>
        public Position(double latitude, double longitude)
        {
            Latitude = latitude;
            Longitude = longitude;
        }

        public static Position Parse(string positionString)
        {
            string[] value = positionString.Split(',');
            double lat = Convert.ToDouble(value[0]);
            double lng = Convert.ToDouble(value[1]);
            Position pos = new Position(lat, lng);
            return pos;
        }
    }

    public class PositionConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            return sourceType == typeof(string);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            return Position.Parse((string)value);
        }
    }
}