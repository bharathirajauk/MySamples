﻿using Android.App;
using Android.Widget;
using Android.OS;
//using Com.Syncfusion.Maps;
using Android.Graphics;
using System.Collections.ObjectModel;
using Android.Views;
//using LayerType = Com.Syncfusion.Maps.LayerType;
using System;
using System.IO;
using System.Net;

namespace Maps
{
    [Activity(Label = "Maps", MainLauncher = true)]
    public class MainActivity : Activity
    {
        ImageView imageView;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.SetBackgroundColor(Color.White);
            linearLayout.Orientation = Orientation.Vertical;

            imageView = new ImageView(this);
            UpdateTiles();
            linearLayout.AddView(imageView);
            SetContentView(linearLayout);
        }

        private  async void UpdateTiles()
        {
            WebClient webClient = new WebClient();
            var imageUri = new System.Uri("http://tile.openstreetmap.org/" + "1" + "/" + "0" + "/" + "0" + ".png");
            webClient = this.AddWebClientHeaderCollection(webClient);
            Bitmap bitmap = await UriAsBitmap(webClient, imageUri);
            imageView.SetImageBitmap(bitmap);
        }

        private WebClient AddWebClientHeaderCollection(WebClient webClient)
        {
            webClient.Headers.Add("Accept: text/html, application/xhtml+xml, */*");
            webClient.Headers.Add("User-Agent: Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)");
            return webClient;
        }

        private async System.Threading.Tasks.Task<Bitmap> UriAsBitmap( WebClient webClient, Uri imageUri)
        {
            byte[] imageBytes = null;
            imageBytes = await webClient.DownloadDataTaskAsync(imageUri);
            var stream = new MemoryStream(imageBytes);
            Bitmap bitmap = await BitmapFactory.DecodeStreamAsync(stream, null, null);
            imageBytes = null;
            stream.Close();
            stream.Dispose();
            stream = null;
            return bitmap;
        }
    }
}

