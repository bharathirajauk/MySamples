﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //control1.ImagePath = ImageSource();

            //this.grid1.Children.Add(control1);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    var saveFileDialog = new SaveFileDialog()
            //    {
            //        Filter = "Image Files (*.bmp, *.png, *.jpg)|*.bmp;*.png;*.jpg"
            //    };
            //    if (saveFileDialog.ShowDialog() == true)
            //    {

            //        var encoder = new PngBitmapEncoder();
            //        encoder.Frames.Add(BitmapFrame.Create((BitmapSource)image1.Source));
            //        using (FileStream stream = new FileStream(saveFileDialog.FileName, FileMode.Create))
            //            encoder.Save(stream);
            //    }

            //}
            //catch (Exception exception)
            //{
            //    MessageBox.Show(exception.Message);
            //}
            RenderTargetBitmap result = GetImage(this.grid1);
            Stream imageStream = new MemoryStream();
            SaveAsPng(result, imageStream);
        }
        public static RenderTargetBitmap GetImage(Grid view)
        {
            Size size = new Size(1122, 750);
            if (size.IsEmpty)
                return null;

            RenderTargetBitmap result = new RenderTargetBitmap((int)size.Width, (int)size.Height, 96, 96, PixelFormats.Pbgra32);

            DrawingVisual drawingvisual = new DrawingVisual();
            using (DrawingContext context = drawingvisual.RenderOpen())
            {
                context.DrawRectangle(new VisualBrush(view), null, new Rect(new Point(), size));
                context.Close();
            }

            result.Render(drawingvisual);
            return result;
        }
        public static void SaveAsPng(RenderTargetBitmap src, Stream outputStream)
        {
            var saveFileDialog = new SaveFileDialog()
            {
                Filter = "Image Files (*.bmp, *.png, *.jpg)|*.bmp;*.png;*.jpg"
            };
            if (saveFileDialog.ShowDialog() == true)
            {

                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(src));
                using (FileStream stream = new FileStream(saveFileDialog.FileName, FileMode.Create))
                    encoder.Save(stream);
            }
        }

        double rotationAngle = 0;
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //Rotate
            this.rotationAngle += 90;
            this.grid1.RenderTransformOrigin = new Point(0.5, 0.5);
            this.grid1.LayoutTransform = new RotateTransform() { Angle = this.rotationAngle };
        }

        bool mIsHorizontalImageflipped = false;
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            //Transform
            int[] value ;
            float[] origin = new float[] { 0.5f, 0.5f };
            string path = "(UIElement.RenderTransform).(ScaleTransform.ScaleX)";
            if (!this.mIsHorizontalImageflipped)
            {
                value = new int[] { 1, -1 };
                this.mIsHorizontalImageflipped = true;
            }
            else
            {
                this.mIsHorizontalImageflipped = false;
              value = new int[] { -1, 1 };
            }
            this.Animate(value, origin, path);
        }
        internal void Animate(int[] value, float[] origin, string path)
        {
            this.grid1.RenderTransform = new ScaleTransform();
            Storyboard sb = new Storyboard();
            this.grid1.RenderTransformOrigin = new Point(origin[0], origin[1]);
            DoubleAnimationUsingKeyFrames keyFrames = new DoubleAnimationUsingKeyFrames();

            SplineDoubleKeyFrame keyFrame = new SplineDoubleKeyFrame();
            keyFrame.KeyTime = KeyTime.FromTimeSpan(TimeSpan.FromSeconds(0));
            keyFrame.Value = value[0];
            keyFrames.KeyFrames.Add(keyFrame);
            keyFrame = new SplineDoubleKeyFrame();
            keyFrame.KeyTime = KeyTime.FromTimeSpan(TimeSpan.FromSeconds(1));

            KeySpline keySpline = new KeySpline();
            keySpline.ControlPoint1 = new Point(0.64, 0.84);
            keySpline.ControlPoint2 = new Point(0, 1);

            keyFrame.KeySpline = keySpline;
            keyFrames.KeyFrames.Add(keyFrame);
            keyFrame.Value = value[1];
            Storyboard.SetTargetProperty(keyFrames, new PropertyPath(path));
            Storyboard.SetTarget(keyFrames, this.grid1);
            sb.Children.Add(keyFrames);
            sb.Begin();
        }
        }
}
