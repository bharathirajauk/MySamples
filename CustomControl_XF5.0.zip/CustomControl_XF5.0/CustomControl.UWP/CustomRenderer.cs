﻿using CustomControl;
using CustomControl.UWP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Xamarin.Forms.Platform.UWP;

[assembly: ExportRenderer(typeof(CustomContentView), typeof(CustomRenderer))]
namespace CustomControl.UWP
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public class CustomRenderer : VisualElementRenderer<CustomControl.CustomContentView, CustomView>
    {
        private CustomView customView;
        public CustomRenderer()
        {
            this.AutoPackage = false;
        }

        protected override void OnElementChanged(ElementChangedEventArgs<CustomContentView> e)
        {
            if (e.NewElement == null)
            {
                return;
            }

            this.customView = new CustomView();
            this.customView.DataContext = this.Element.BindingContext;
            this.SetNativeControl(this.customView);

            if (Element.Content != null)
            {
                var renderer = Element.Content.GetOrCreateRenderer();
                var contentControl = new ContentControl();

                contentControl.Content = renderer.ContainerElement;
                this.customView.Content = contentControl;
            }

            base.OnElementChanged(e);
        }


    }

    /// <summary>
    /// Native control of UWP 
    /// </summary>
    public class CustomView : ContentPresenter
    {
        public CustomView()
        {
        }
    }
}

